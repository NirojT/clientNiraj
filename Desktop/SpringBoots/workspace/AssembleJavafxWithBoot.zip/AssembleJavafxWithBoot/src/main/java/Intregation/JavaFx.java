package Intregation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericApplicationContext;

import Intregation.Entity.Admin;
import Intregation.reposiotery.ARepo;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import net.rgielen.fxweaver.core.FxWeaver;

public class JavaFx extends Application {

	@Autowired
	private ARepo aRepo;
	private ConfigurableApplicationContext context;

@Override
public void init() throws Exception {
ApplicationContextInitializer<GenericApplicationContext> initializer =
ac ->
{
		ac.registerBean (Application.class, ()-> JavaFx.this);
		ac.registerBean (Parameters.class, ()->getParameters());
		ac.registerBean (HostServices.class, ()-> getHostServices());
		
	
	};

	
	this.context=new SpringApplicationBuilder()
			.sources(AssembleJavafxWithBootApplication.class)
			.initializers(initializer)
			.run(getParameters().getRaw().toArray(new String[0]));



	
	

}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		  // Create a JavaFX button
	    Button button = new Button("Click Me!");

	    // Set an action for the button
	    button.setOnAction(event -> {
	        // Handle button click event here
	        System.out.println("Button clicked!");
	     Admin findByNameAndPassword = aRepo.findByNameAndPassword("a","a");
	     if (findByNameAndPassword==null) {
			System.out.println("didnot found");
			return;
		}
	     System.out.println(" found");
	        
	    });

	    // Create a layout for the button
	    StackPane root = new StackPane();
	    root.getChildren().add(button);

	    // Set up the JavaFX scene and stage
	    Scene scene = new Scene(root, 300, 200);
	    primaryStage.setScene(scene);
	    primaryStage.setTitle("JavaFX Application");
	    primaryStage.show();
	    }
	 @Override
	    public void stop() throws Exception {
	        context.close();
	        Platform.exit();
	    }
}
