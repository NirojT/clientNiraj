package Intregation.reposiotery;

import org.springframework.data.jpa.repository.JpaRepository;

import Intregation.Entity.Admin;
import java.util.List;


public interface ARepo extends JpaRepository<Admin, Integer> {
	
	Admin findByNameAndPassword(String name, String password);

}
