package Intregation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssembleJavafxWithBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
